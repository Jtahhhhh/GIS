<div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.php"> <img alt="image" src="../images/logotaxi.png" style="height: 100px;" class="header-logo" /> 
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Quản lý chuyến xe</span></a>
              <ul class="dropdown-menu">
              <li><a class="nav-link" href="xacnhanchuyendi.php">Xác nhận chuyến đi</a></li>
              <li><a class="nav-link" href="xemchitietdanhgia.php">Thông tin đánh giá</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="briefcase"></i><span>Xe</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="danhsachxe.php">Danh sách xe</a></li>
              </ul>
            </li>
          
          </ul>
        </aside>
      </div>